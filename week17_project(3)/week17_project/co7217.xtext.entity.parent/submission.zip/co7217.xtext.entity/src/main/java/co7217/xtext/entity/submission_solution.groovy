package co7217.xtext.entity 

import submission_helper.SubmissionHelper

def solution = { /* no need to add anything here! */ }

/**
 *  RUN 
 *  
 *  ./gradlew clean test 
 *  
 *  before executing this file.
 *  
 *  Check the solution with the SubmissionHelper
 *  
 *  DO NOT FORGET TO SUBMIT THE CONFIRMATION NUMERIC CODE on Blackboard
 *  
 */
SubmissionHelper.check_solution('svtt1', 'week_7', solution);