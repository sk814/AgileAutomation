package exercises 

import org.bson.Document
import submission_helper.SubmissionHelper
import com.mongodb.client.MongoClients
import com.mongodb.client.model.FindOneAndUpdateOptions
import com.mongodb.client.model.UpdateOptions
import static com.mongodb.client.model.Filters.*;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def path = 'src/main/resources/top-rated-movies.json'
//def path = 'src/main/resources/top-rated-movies-short.json'

def solution = { filePath ->
	// load credentials from src/main/resources/mongodb.properties
	// this file should contain
	//		USN=yourUsername
	//		PWD=yourPassword
	//		DATABASE=yourDatabaseName
	def properties = new Properties()
	def propertiesFile = new File('src/main/resources/mongodb.properties')
	propertiesFile.withInputStream {
		properties.load(it)
	}
	

// MAKING THE CONNECTION
def mongoClient = MongoClients.create("mongodb+srv://${properties.USN}:${properties.PWD}@cluster0.tmcag.mongodb.net/${properties.DB}?retryWrites=true&w=majority")
//mongodb+srv://sfs16:<password>@cluster0.tmcag.mongodb.net/<dbname>?retryWrites=true&w=majority
// GET DATABASE
def db = mongoClient.getDatabase(properties.DB)

// TESTING CONNECTION
println 'database: ' + db.getName()
db.listCollectionNames().each{ println it } 


def col = db.getCollection("movies-collection")

// DELETE PREVIOUS CONTENTS
def filterObject = new Document()
col.deleteMany(filterObject)

def document = new Document()

def json= new File(filePath)
def jsonSluper  =new  JsonSlurper()
json = jsonSluper.parseText(json.text)

for (i in json)
	col.insertOne(Document.parse(JsonOutput.toJson(i)))
	
	println "before insert: " + col.countDocuments()

	document.putAll(
		[title: "The Imitation Game",
		year: 2014,
		genres: [ "Biography", "Drama", "Thriller", "War" ],
		imdbRating: 8,
		actors: [ "Benedict Cumberbatch", "Keira Knightley", "Matthew Goode"]
		])
	
	
		
		col.insertOne(document)
		
		println "aftrr insert: " + col.countDocuments()
		
		
		def filteredList = col.find(gte("imdbRating",8))
		filteredList = filteredList.sort{it.year + it.title}
		filteredList = filteredList.collect{ it.title + "_" + it.year}
		
		return filteredList
}



// desk check your solution twice: both attempts should give the same result
println('first attempt:')
println(solution(path).inspect())
println('second attempt:')
println(solution(path).inspect())

// check the solution with the SubmissionHelper
// DO NOT FORGET TO SUBMIT THE CONFIRMATION NUMERIC CODE on Blackboard
SubmissionHelper.check_solution('sfs16', 'week_3', solution);