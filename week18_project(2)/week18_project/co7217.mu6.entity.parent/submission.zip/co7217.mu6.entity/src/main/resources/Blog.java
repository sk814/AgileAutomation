


public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}



public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}



public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}



public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}



public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}



public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}



public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}



public class Blog  {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private Post posts;
	
	public Post getPosts() {
		return posts;
	}
	
	public void setPosts(Post posts) {
		this.posts = posts;
	}

}
