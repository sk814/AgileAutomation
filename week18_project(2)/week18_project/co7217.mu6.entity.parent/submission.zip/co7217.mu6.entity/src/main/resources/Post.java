


public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}



public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}



public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}



public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}



public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}



public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}



public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}



public class Post extends HasAuthor {
			
	private String title;
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
		
	private String content;
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
		
	private Comment comments;
	
	public Comment getComments() {
		return comments;
	}
	
	public void setComments(Comment comments) {
		this.comments = comments;
	}

}
