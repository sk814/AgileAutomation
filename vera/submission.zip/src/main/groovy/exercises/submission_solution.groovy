package exercises 

import org.bson.Document
import submission_helper.SubmissionHelper
import com.mongodb.client.MongoClients
import com.mongodb.client.model.FindOneAndUpdateOptions
import com.mongodb.client.model.UpdateOptions
import static com.mongodb.client.model.Filters.*;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput


def path = 'src/main/resources/top-rated-movies.json'
//def path = 'src/main/resources/top-rated-movies-short.json'

def solution = { filePath ->
	def properties = new Properties()
	def propertiesFile = new File('src/main/resources/mongodb.properties')
	propertiesFile.withInputStream {
		properties.load(it)
	}
	

def mongoClient = MongoClients.create("mongodb+srv://${properties.USN}:${properties.PWD}@cluster0.6vssc.mongodb.net/${properties.DB}?retryWrites=true&w=majority")

def db = mongoClient.getDatabase(properties.DB)

def collection = db.getCollection("movies-collection")

// RESET DB
def fb = new Document()
collection.deleteMany(fb)

def json= new File(filePath)
def jsonSluper  =new  JsonSlurper()
json = jsonSluper.parseText(json.text)

for (each in json)
	collection.insertOne(Document.parse(JsonOutput.toJson(each)))
	
	def document = new Document()
	document.putAll(
		[title: "The Imitation Game",
		year: 2014,
		genres: [ "Biography", "Drama", "Thriller", "War" ],
		imdbRating: 8,
		actors: [ "Benedict Cumberbatch", "Keira Knightley", "Matthew Goode"]
		])
		collection.insertOne(document)
		
		return collection.find(gte("imdbRating",8)).sort{it.year + it.title}.collect{ it.title + "_" + it.year}
}



// desk check your solution twice: both attempts should give the same result
println('first attempt:')
println(solution(path).inspect())
println('second attempt:')
println(solution(path).inspect())

// check the solution with the SubmissionHelper
// DO NOT FORGET TO SUBMIT THE CONFIRMATION NUMERIC CODE on Blackboard
SubmissionHelper.check_solution('skng1', 'week_3', solution);

